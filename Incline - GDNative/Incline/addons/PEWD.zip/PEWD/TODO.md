# TODO
 - Add Modifiers for bullets to the Bullet server
 - Add function to spawn modified bullets